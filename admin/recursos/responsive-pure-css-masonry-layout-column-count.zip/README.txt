A Pen created at CodePen.io. You can find this one at http://codepen.io/ramenhog/pen/dvZVda.

 Responsive column masonry layout with CSS column count

Tutorial blog post here: http://codepen.io/ramenhog/post/an-exercise-in-css-masonry