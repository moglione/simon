A Pen created at CodePen.io. You can find this one at http://codepen.io/abhishek/pen/BKZvyy.

 magic line navigation with css only :)